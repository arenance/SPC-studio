const STORAGE_KEY = "spc-studio-workspaces-v1";

export function loadWorkspaces() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

export function saveWorkspaces(workspaces) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(workspaces));
}

export function createId() {
  return globalThis.crypto?.randomUUID?.() ||
    `spc-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
