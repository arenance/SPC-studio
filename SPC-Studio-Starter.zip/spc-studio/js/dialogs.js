const dialog = document.getElementById("nameDialog");
const title = document.getElementById("dialogTitle");
const description = document.getElementById("dialogDescription");
const input = document.getElementById("nameInput");
const confirmButton = document.getElementById("dialogConfirm");

export function askName({heading, help, placeholder = "Name", confirm = "Create"}) {
  title.textContent = heading;
  description.textContent = help;
  input.value = "";
  input.placeholder = placeholder;
  confirmButton.textContent = confirm;
  dialog.showModal();
  input.focus();

  return new Promise(resolve => {
    const onClose = () => {
      dialog.removeEventListener("close", onClose);
      resolve(dialog.returnValue === "confirm" ? input.value.trim() : null);
    };
    dialog.addEventListener("close", onClose);
  });
}
