export function renderTree(container, nodes, {selectedId, onSelect, onToggle}) {
  container.replaceChildren();

  function renderNodes(items, parent, depth = 0) {
    for (const node of items) {
      const row = document.createElement("div");
      row.className = `tree-row${node.id === selectedId ? " selected" : ""}`;
      row.style.paddingLeft = `${6 + depth * 12}px`;

      const icon = document.createElement("span");
      icon.className = "tree-icon";
      icon.textContent = node.type === "folder" ? (node.expanded ? "▾" : "▸") : "◇";

      const name = document.createElement("span");
      name.className = "tree-name";
      name.textContent = node.name;

      row.append(icon, name);
      row.addEventListener("click", () => {
        onSelect(node);
        if (node.type === "folder") onToggle(node);
      });
      parent.appendChild(row);

      if (node.type === "folder" && node.expanded && node.children?.length) {
        const children = document.createElement("div");
        children.className = "tree-children";
        parent.appendChild(children);
        renderNodes(node.children, children, depth + 1);
      }
    }
  }

  renderNodes(nodes, container);
}
