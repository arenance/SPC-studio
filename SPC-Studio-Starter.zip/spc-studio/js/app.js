import {loadWorkspaces, saveWorkspaces, createId} from "./storage.js";
import {askName} from "./dialogs.js";
import {renderTree} from "./tree.js";

const $ = id => document.getElementById(id);
let workspaces = loadWorkspaces();
let activeWorkspace = null;
let selectedNode = null;
let activeFile = null;
let openFiles = [];

function persist() { saveWorkspaces(workspaces); }
function findParent(items, target) {
  for (const item of items) {
    if (item === target) return items;
    if (item.type === "folder") {
      const found = findParent(item.children, target);
      if (found) return found;
    }
  }
  return null;
}
function allFiles(items, result = []) {
  for (const item of items) {
    if (item.type === "file") result.push(item);
    else allFiles(item.children || [], result);
  }
  return result;
}
function showDashboard() {
  $("dashboard").classList.remove("hidden");
  $("workbench").classList.add("hidden");
  $("workspaceName").textContent = "No workspace open";
  activeWorkspace = null;
  selectedNode = null;
  activeFile = null;
  openFiles = [];
  renderRecent();
}
function showWorkbench(workspace) {
  activeWorkspace = workspace;
  selectedNode = null;
  activeFile = null;
  openFiles = [];
  $("dashboard").classList.add("hidden");
  $("workbench").classList.remove("hidden");
  $("workspaceName").textContent = workspace.name;
  $("treeWorkspaceName").textContent = workspace.name.toUpperCase();
  $("editorWelcome").classList.remove("hidden");
  $("editorContainer").classList.add("hidden");
  renderExplorer();
  renderTabs();
  log(`Opened workspace "${workspace.name}".`);
}
function log(message) { $("output").textContent = message; }

function renderRecent() {
  const host = $("recentWorkspaces");
  host.replaceChildren();
  if (!workspaces.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No workspaces yet. Create one to get started.";
    host.appendChild(empty);
    return;
  }
  [...workspaces].reverse().forEach(workspace => {
    const card = document.createElement("button");
    card.className = "recent-card";
    const name = document.createElement("strong");
    name.textContent = "📁 " + workspace.name;
    const info = document.createElement("small");
    info.textContent = `${allFiles(workspace.files).length} files`;
    card.append(name, info);
    card.addEventListener("click", () => showWorkbench(workspace));
    host.appendChild(card);
  });
}
function renderExplorer() {
  renderTree($("fileTree"), activeWorkspace.files, {
    selectedId: selectedNode?.id,
    onSelect(node) {
      selectedNode = node;
      if (node.type === "file") openFile(node);
      else renderExplorer();
    },
    onToggle(node) {
      node.expanded = !node.expanded;
      persist();
      renderExplorer();
    }
  });
}
function renderTabs() {
  const tabs = $("tabs");
  tabs.replaceChildren();
  openFiles.forEach(file => {
    const tab = document.createElement("div");
    tab.className = `tab${activeFile?.id === file.id ? " active" : ""}`;
    tab.textContent = file.name;
    tab.addEventListener("click", () => openFile(file));
    tabs.appendChild(tab);
  });
}
function openFile(file) {
  saveActiveFile();
  activeFile = file;
  if (!openFiles.some(item => item.id === file.id)) openFiles.push(file);
  $("editorWelcome").classList.add("hidden");
  $("editorContainer").classList.remove("hidden");
  $("activeFileName").textContent = file.name;
  $("codeEditor").value = file.content || "";
  $("saveStatus").textContent = "Saved";
  renderTabs();
}
function saveActiveFile() {
  if (!activeFile) return;
  activeFile.content = $("codeEditor").value;
  persist();
  $("saveStatus").textContent = "Saved";
}
async function createWorkspace() {
  const name = await askName({heading:"Create workspace",help:"Choose a name for your new, empty workspace.",placeholder:"my-project"});
  if (!name) return;
  const workspace = {id:createId(), name, files:[], createdAt:Date.now()};
  workspaces.push(workspace);
  persist();
  renderRecent();
  showWorkbench(workspace);
}
async function createNode(type) {
  if (!activeWorkspace) return;
  const name = await askName({
    heading: type === "folder" ? "Create folder" : "Create file",
    help: type === "folder" ? "Create a folder in the selected folder or workspace root." : "Enter a filename, for example home.spc.",
    placeholder: type === "folder" ? "new-folder" : "home.spc"
  });
  if (!name) return;
  const node = type === "folder"
    ? {id:createId(), name, type, expanded:true, children:[]}
    : {id:createId(), name, type, content:""};
  const destination = selectedNode?.type === "folder" ? selectedNode.children : activeWorkspace.files;
  destination.push(node);
  selectedNode = node;
  persist();
  renderExplorer();
  if (type === "file") openFile(node);
  log(`${type === "folder" ? "Created folder" : "Created file"} "${name}".`);
}
async function renameSelected() {
  if (!selectedNode) return alert("Select a file or folder first.");
  const name = await askName({heading:"Rename",help:"Enter the new name.",placeholder:selectedNode.name});
  if (!name) return;
  selectedNode.name = name;
  persist();
  renderExplorer();
  if (activeFile?.id === selectedNode.id) {
    $("activeFileName").textContent = name;
    renderTabs();
  }
  log(`Renamed to "${name}".`);
}
function deleteSelected() {
  if (!selectedNode) return alert("Select a file or folder first.");
  if (!confirm(`Delete "${selectedNode.name}" and its contents?`)) return;
  const removed = selectedNode;
  const parent = findParent(activeWorkspace.files, removed);
  if (parent) parent.splice(parent.indexOf(removed), 1);
  const removedIds = new Set([removed.id, ...allFiles(removed.children || []).map(f => f.id)]);
  openFiles = openFiles.filter(f => !removedIds.has(f.id));
  if (activeFile && removedIds.has(activeFile.id)) {
    activeFile = null;
    $("editorContainer").classList.add("hidden");
    $("editorWelcome").classList.remove("hidden");
  }
  selectedNode = null;
  persist();
  renderExplorer();
  renderTabs();
  log(`Deleted "${removed.name}".`);
}
function openWorkspaceImport() { $("importWorkspaceInput").click(); }
function exportWorkspace() {
  if (!activeWorkspace) return;
  saveActiveFile();
  const blob = new Blob([JSON.stringify(activeWorkspace, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${activeWorkspace.name.replace(/[^a-z0-9-_]/gi,"-")}.spc-workspace.json`;
  a.click();
  URL.revokeObjectURL(url);
  log("Workspace exported as JSON.");
}
$("createWorkspaceButton").addEventListener("click", createWorkspace);
$("openWorkspaceButton").addEventListener("click", openWorkspaceImport);
$("homeButton").addEventListener("click", () => { saveActiveFile(); showDashboard(); });
$("newFileButton").addEventListener("click", () => createNode("file"));
$("newFolderButton").addEventListener("click", () => createNode("folder"));
$("quickFileButton").addEventListener("click", () => createNode("file"));
$("quickFolderButton").addEventListener("click", () => createNode("folder"));
$("codeEditor").addEventListener("input", () => {
  $("saveStatus").textContent = "Unsaved";
  clearTimeout(window.spcSaveTimer);
  window.spcSaveTimer = setTimeout(saveActiveFile, 500);
});
$("codeEditor").addEventListener("keydown", event => {
  if (event.key === "Tab") {
    event.preventDefault();
    const editor = event.currentTarget;
    const start = editor.selectionStart, end = editor.selectionEnd;
    editor.setRangeText("    ", start, end, "end");
    editor.dispatchEvent(new Event("input"));
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
    event.preventDefault(); saveActiveFile();
  }
});
$("importWorkspaceInput").addEventListener("change", async event => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!data || typeof data.name !== "string" || !Array.isArray(data.files)) throw new Error("Invalid workspace file.");
    if (!data.id) data.id = createId();
    workspaces = workspaces.filter(w => w.id !== data.id);
    workspaces.push(data);
    persist();
    renderRecent();
    showWorkbench(data);
  } catch (error) { alert(`Could not open workspace: ${error.message}`); }
  event.target.value = "";
});
$("settingsButton").addEventListener("click", () => alert("Settings will be added in a later development stage."));
$("settingsButton2").addEventListener("click", () => alert("Settings will be added in a later development stage."));
$("searchButton").addEventListener("click", () => {
  const query = prompt("Search text in this workspace:");
  if (!query || !activeWorkspace) return;
  const matches = allFiles(activeWorkspace.files).filter(file => (file.content || "").includes(query));
  log(matches.length ? `Found "${query}" in: ${matches.map(f => f.name).join(", ")}` : `No matches for "${query}".`);
});
$("tabs").addEventListener("contextmenu", event => event.preventDefault());

// A small command menu for actions not placed on the compact mobile toolbar.
document.addEventListener("keydown", event => {
  if (event.key === "F2") { event.preventDefault(); renameSelected(); }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "e") { event.preventDefault(); exportWorkspace(); }
});
renderRecent();
