# SPC Studio

SPC Studio is an early browser-based development environment for the SPC programming language.

## Included in this starter build

- Create empty workspaces
- Create nested folders and files
- Open files in editor tabs
- Rename and delete files/folders
- Autosave editor content in browser local storage
- Export a workspace as a JSON file
- Import a previously exported workspace
- Search text across files in the open workspace
- Responsive interface for mobile and desktop

## Run locally

Because this project uses JavaScript modules, open it through a local web server rather than opening `index.html` directly.

For example, use the Live Server extension or another local static server, then open the local address in your browser.

## Publish with GitHub Pages

1. Upload the contents of this folder to the root of your `spc-studio` repository.
2. In GitHub, open **Settings → Pages**.
3. Under Build and deployment, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site.

## Important limitations of this starter build

- The SPC compiler/interpreter is not connected yet. The output panel clearly indicates this.
- Syntax highlighting and language-aware autocomplete are not implemented yet.
- Workspaces are stored in the current browser's local storage. They do not automatically sync between devices or browsers.
- Export a workspace JSON file regularly as a backup.
- This is a starter prototype, not yet a production IDE.
